/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package listas.ejercicio07;

/**
 *
 * @author KevinR
 */
public class Ejecutor {

    public static void main(String[] args) {
        Metodos obj = new Metodos();
        int opc;
         do{
        opc = obj.menu();
            switch(opc){
                case 1:
                    obj.llenar();
                    break;
                case 2:
                    obj.ordenar();
                    break;
                case 3:
                    obj.recorrer();
                    break;
            }
        }while(opc != 0);
    }
}
